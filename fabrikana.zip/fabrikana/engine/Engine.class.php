<?php

if (!defined('PROTECT')){die('Protected Content!');}

class Engine {
	
	public static function Login($username, $password, $remember) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$link = new DB();
		$query = "SELECT * FROM users WHERE username = ? AND password = ? AND activ = 1";
		$result = $link->GetRow($query, [$username, $password]);
		
		if ($result) {
			
			$_SESSION[SITE] = array(
			
				'username'		=> $result['username'],
				'session'		=> $result['session'],
				'usertype'		=> $result['usertype']
			);
			
			if ($remember == 1) {
				
				setcookie(SITE, $result['session'], time()+3600*24*30, '/');
			}
			
			header('Location: '.ROOT.LANG.'/blog');
		} else {
			
			return "<p class='red'>$c[nouser]</p>";
		}
	}
	
	public static function Contact($email, $message) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			
			return "<p class='red'>$c[nevem]</p>";
		} else {
			
			mail(EMAIL, 'Message from site SkupRa', $message."\n\n$email", 'From:'.$email);
			
			header('Location: '.ROOT.LANG.'/info/email-sent');
		}
	}
	
	public static function SelectBox($catid) {

		$link = new DB();

		$query = "SELECT * FROM categories";
		$result = $link->GetRows($query);

		$output = '';

		foreach ($result as $cat) {

			if ($catid != '') {
				if ($cat['catid'] == $catid) {
					
					$selected = 'selected';
				} else {
					
					$selected = '';
				}
			} else {
				
				$selected = '';
			}
			
			$output .= "<option value='$cat[catid]' $selected>$cat[catname]</option>";
		}

		return $output;
	}
	
	public static function Write($engleski, $header, $header_en, $catid, $text, $text_en, $authorid, $minview, $comments) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$seo = self::SEO($header);
		
		$date = date("Y-m-d");
		
		$dateseo = date("d-m-Y");
		$seo = $seo.'-'.$dateseo;
		
		$link = new DB();
		$query = "SELECT * FROM articles WHERE seo = ?";
		$result = $link->GetRow($query, [$seo]);
		
		if ($result) {
			
			return "<p class='red'>$c[promese]</p>";
		} else {
			
			$query = "INSERT INTO articles(engleski, header, header_en, seo, date, catid, tekst, tekst_en, pregledi, authorid, minview, comments) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			$result = $link->InsertRow($query, [$engleski, $header, $header_en, $seo, $date, $catid, $text, $text_en, 0, $authorid, $minview, $comments]);
			
			header('Location: '.ROOT.LANG.'/info/write-success');
		}
	}
	
	private static function SEO($input) {

		$cir = array (
			
			"А" => "a", "Б" => "b", "В" => "v", "Г" => "g", "Д" => "d", "Ђ" => "dj", "Е" => "e", "Ж" => "z", "З" => "z", "И" => "i", 
			"Ј" => "j", "К" => "k", "Л" => "l", "Љ" => "lj", "М" => "m", "Н" => "n", "Њ" => "nj", "О" => "o", "П" => "p", "Р" => "r", 
			"С" => "s", "Т" => "t", "Ћ" => "c", "У" => "u", "Ф" => "f", "Х" => "h", "Ц" => "c", "Ч" => "c", "Џ" => "dz", "Ш" => "s", 

			"а" => "a", "б" => "b", "в" => "v", "г" => "g", "д" => "d", "ђ" => "dj", "е" => "e", "ж" => "z", "з" => "z", "и" => "i", 
			"ј" => "j", "к" => "k", "л" => "l", "љ" => "lj", "м" => "m", "н" => "n", "њ" => "nj", "о" => "o", "п" => "p", "р" => "r", 
			"с" => "s", "т" => "t", "ћ" => "c", "у" => "u", "ф" => "f", "х" => "h", "ц" => "c", "ч" => "c", "џ" => "dz", "ш" => "s",
			
			"Š" => "s", "Đ" => "dj", "Č" => "c", "Ć" => "c", "Ž" => "z",
			"š" => "s", "đ" => "dj", "č" => "c", "ć" => "c", "ž" => "z"
		);

		$output = strtr($input, $cir);
		$output = strtolower($output);
		$output = preg_replace("/[\s]/", "-", $output);
		$output = preg_replace("/[^a-z0-9-_]/",'',$output);

		return $output;
	}
	
	public static function Pagination($page, $num_page, $folder) {

		$pag1 = "<div id='pagi'>";
		$pag2 = '';

		for($i = 1; $i <= $num_page; $i++) {
			
			if($i==$page) {
				
				$pag2 .= "&nbsp;".$i."&nbsp;";
			} else {
				
				$pag2 .= "&nbsp;<a href='".ROOT.LANG.'/'.$folder.'/'.$i."'>".$i."</a>&nbsp;";
			}
		}
		
		$pag3 = '</div>';

		return $pag1.$pag2.$pag3;
	}
	
	public static function Edit($engleski, $header_en, $tekst_en, $artid, $header, $seo, $oldseo, $catid, $tekst, $minview, $comments) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$link = new DB();
		
		$seo = self::SEO($seo);
		
		if ($seo == $oldseo) {

			$query = "UPDATE articles SET engleski = ?, header_en = ?, tekst_en = ?, header = ?, catid = ?, tekst = ?, minview = ?, comments = ? WHERE artid = ?";
			$result = $link->UpdateRow($query, [$engleski, $header_en, $tekst_en, $header, $catid, $tekst, $minview, $comments, $artid]);
		} else {

			$query = "SELECT * FROM articles WHERE seo = ?";
			$result = $link->GetRow($query, [$seo]);

			if ($result) {

				return "<p class='red'>".$c['prose']."</p>";
			} else {

				$query = "UPDATE articles SET engleski = ?, header_en = ?, tekst_en = ?, header = ?, seo = ?, catid = ?, tekst = ?, minview = ?, comments = ? WHERE artid = ?";
				$result = $link->UpdateRow($query, [$engleski, $header_en, $tekst_en, $header, $seo, $catid, $tekst, $minview, $comments, $artid]);
			}
		}

		if ($result) {
			
			header('Location: '.ROOT.LANG.'/info/edit-success');
		}
	}
	
	public static function AddCategory($catname, $opis, $catname_en, $opis_en, $image) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$catseo = self::SEO($catname);
		
		$link = new DB();
		$query = "SELECT * FROM categories WHERE catseo = ?";
		$result = $link->GetRow($query, [$catseo]);
		
		if ($result) {
			
			return "<p class='red'>$c[catex]</p>";
		} else {
			
			$query = "INSERT INTO categories (catname, catname_en, catdesc_en, catseo, catdesc, image) VALUES (?, ?, ?, ?, ?, ?)";
			$result = $link->InsertRow($query, [$catname, $catname_en, $opis_en, $catseo, $opis, $image]);
			
			if ($result) {
				
				header('Location: '.ROOT.LANG.'/info/add-category-success');
			}
		}
	}
	
	public static function EditCategory($catid, $catname, $oldcatname, $opis, $image, $catname_en, $opis_en) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$catseo = self::SEO($catname);
		$oldcatseo = self::SEO($oldcatname);
		
		$link = new DB();
		
		if ($catseo == $oldcatseo) {
			
			$query = "UPDATE categories SET catname = ?, catdesc = ?, image = ?, catname_en = ?, catdesc_en = ? WHERE catid = ?";
			$result = $link->UpdateRow($query, [$catname, $opis, $image, $catname_en, $opis_en, $catid]);
			
			if ($result) {
				
				header('Location: '.ROOT.LANG.'/info/edit-category-success');
			}
		} else {
			
			$query = "SELECT * FROM categories WHERE catseo = ?";
			$result = $link->GetRow($query, [$catseo]);
			
			if ($result) {
				
				return "<p class='red'>$c[catexe]</p>";
			} else {
				
				$query = "UPDATE categories SET catname = ?, catseo = ?, catdesc = ?, image = ?, catname_en = ?, catdesc_en = ? WHERE catid = ?";
				$result = $link->UpdateRow($query, [$catname, $catseo, $opis, $image, $catname_en, $opis_en, $catid]);
				
				if ($result) {
				
					header('Location: '.ROOT.LANG.'/info/edit-category-success');
				}
			}
		}
	}
	
	public static function CatName($catid, $engleski) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$link = new DB();
		
		if ($engleski == 0) {

			$query = "SELECT catname FROM categories WHERE catid = ?";

			$result = $link->GetRow($query, [$catid]);
		
			if ($result) {
				
				return $result['catname'];
			} else {
				
				return $c['nocat'];
			}
		} else {

			$query = "SELECT catname_en FROM categories WHERE catid = ?";

			$result = $link->GetRow($query, [$catid]);
		
			if ($result) {
				
				return $result['catname_en'];
			} else {
				
				return $c['nocat'];
			}
		}
	}
	
	public static function CatId($catseo) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$link = new DB();
		
		$query = "SELECT catid FROM categories WHERE catseo = ?";
		$result = $link->GetRow($query, [$catseo]);
		
		if ($result) {
			
			return $result['catid'];
		} else {
			
			return $c['nocat'];
		}
	}
	
	public static function AuthorId($username) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$link = new DB();
		
		$query = "SELECT userid FROM users WHERE username = ?";
		$result = $link->GetRow($query, [$username]);
		
		if ($result) {
			
			return $result['userid'];
		} else {
			
			return $c['noauthor'];
		}
	}
	
	public static function Author($userid) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$link = new DB();
		
		$query = "SELECT username FROM users WHERE userid = ?";
		$result = $link->GetRow($query, [$userid]);
		
		if ($result) {
			
			return $result['username'];
		} else {
			
			return $c['noauthor'];
		}
	}

	public static function CatSeo($catid) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		$link = new DB();
		
		$query = "SELECT catseo FROM categories WHERE catid = ?";
		$result = $link->GetRow($query, [$catid]);
		
		if ($result) {
			
			return $result['catseo'];
		} else {
			
			return $c['nocat'];
		}
	}

	public static function Forgot($email) {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			
			return "<p class='red'>$c[nevem]</p>";
		} else {

			$link = new DB();
			$query = "SELECT * FROM users WHERE email = ?";
			$result = $link->GetRow($query, [$email]);

			if ($result) {
				
				$to = $email;

				$subject = 'Fabrikana';

				$headers = "From: office@fabrikana.com\r\n";
				$headers .= "MIME-Version: 1.0\r\n";
				$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
				
				$txt =
				"<style>
					a {
						color: darkorange;
						text-decoration: none;
					}
					a:hover {
						color: #ccc;
					}
				</style>
				<center>

				 <img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUAAAAB2CAYAAAC5xEquAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAABZ+SURBVHja7J0NbBzHdccf9cGjKB1JfZmRaDtUpVgSpUqBhcoQZDsVYEBOgACy0DRA4dSqi4hNgaaVmhZNXRQF0tYF2sqGCyR1iigy4BZ10yoqCqQh6sCtbMG10gS2HMqSLVl0LEqmKVIkj1/Hr+u8vbfk8nS8m7c7uzu7fD9gwaNELufevfnvmzdvZmoKhQIIgiAsRpaICQRBEAEUBEEQARQEQRABFARBEAEUBEEQARQEQRABFARBSD7LdH6opqZGLCUIQmJZqN55mc/7xamIUrktCEJ0EWAJD6qrLcY2X1TXa/LRCYIQtQC2nToC7U/sg8fjanBNO7SrL+ckEhQEISgyCSIIggigIAiCCKAgCIIIoCAIggigIAiCCKAgCIIIoCAIggigIAiCCKAgCIIIoCAIggigIAiCCKAgCIIIoCAIggigIAiCCKAgCIIIoCAIggigIAiCCKAgCELYLIvzjz/6HDzV0Qm3mL+GZ4LIdviCICRbAImX1DXE+HkRP0EQUiOAImqCIMSC5AAFQRABFARBEAEUBEEQARQEQRABFARBSCXLUvzeagzco5CgvxtWe+JsSyHC+9WEZJM4/KEmYvsWktpH0iiA69TVpq5tBu7Vp65OdV3S/PkH6W8H5Zq6euk1/u1xn/cx0R60wVXP993quuXDAf20BYvez6trwuD9XjNwr4XuE7cf1qprL+O94Pt4S125gDap9DnZ0jcXjQC2vfF1+PO9rfBQ0Bv1DMEHn/gD+H1NI7edOgLtT+yDx4P+3Ys34Sfv9sAH+PqPTsOrl3ugR718hxxtQtcOJtqDNnj9ffiJ+/1/XIBLJ885bdN1et9tOfMmnH7sW/AN9fJNE/d74XV48cgp6Ke2u2w+8QX40rFH4KjufZ55Gb59/Htws+TBYIMftn3/K3Ds0KfhsM59f3QJOh55Bv5MvfzfIPat8DnZ0jcXlQA23JV1njSBqVsOK+mpGq2Cb4A9eOFrdObBMbj1ymU4q5zsn0w89Tg0N8AnVRs+6X6vXsN3fn3W6SNvTwis33X33PvT4fmzzsOoO+l+uHOjE4m1LOa+mcZJkOzqelhv4kaNK5wPK2soZxGoHSiEH/01/O3BHc7TfXfcRratPQFoISHQjjxURP6hRlrCej/Eh9vWZrgH9WSx9s00CmBGPR3qTd1MdXA0dIMNbwwd9qUvwzHltAfUt5ssa09LAn2lDgUA34fuL/zshhPtdqfFD9sfhu0RfnbW2SRtAogO3ZRZZs7I99/rPLGytrxBfPL98HedfNUOW9pz+itOrqgtgf7SQgKgzYXrTv6zNy1+SMP/9Yu1b6ZNADOt68wZGFEfmjURoEvrWth+6gh80ZahJ+YrT3wBfgXMzO5FSVj5v8T4YYR5QCttYosA1mhcWjkGeiqYjHDwQ6u1rece+jQ8alPU9Wt74aAtUSknAgwr/5cUP4wwD2ilTWyYBf6i5s9h7gXLFyptoNpATwVjbGxyPrQG23ouDj1VFPi5I6ecOq6LcbcHO9KT++H+k+fgrMYQ0ZZ0SVj5v0T5IaYBjn/PiQKvhmhvK20SqwD+8KvwF7o/e74LXn3gafgT9fJshR+rpaeCMVZlnPtlbOzBv9Q6m8C+aEN7Pr8LtikBbEmIAIaV/0ucH3rygGEKoJU2Sd0kSLbOqQ8yxtqV9uUAXTavj3QGryr3NUeWUDcBK/+Xn4JRFSW9rikSifLDiPKAVtokbQKY3dBoNsxuqrdrFtgLzqipYeenbBEd2wS5WgTIyf9d7dWa/EikH1IaYC2EW+9qpU1SNwtcX2s2zEaRwel7CClJjCsqatqhfdufwjEc5vt4ehuNDNz24HIvTPrbZCuT0Qg3/0dLE3vT6ofqQYq2WLfY+mbqIkBTleZe9m8JPQo8f7kHXnzgafgWLnvj/OKmdbMV8Ubbo4Z7zzxxCr7N/cXD94fekYxEf9z8H66B5kSASfNDzN+GHL1baZM0CSCG71laImN6iBDFRAgK37X/+2Bu4wEdQpwdvNTRCRe6+pyhnzbrV9k7aeRtJjf/d/IcvKcZASbSD0PO31prkzQJYEaFw6wQWzfairAYeuj6bd4Masiz1EMf53gR6ZqViRDAMPN/ifTDkPO31tokTQKYpXBY28C3R/XEJsJi6CE1FGYJDuVVQhPAGwMlNsJdAKdLrkkoboqlrsblC9gKS4eH6cLd5/Ak6EG63O9znp8ZhsrlxlP0d0vbMqPVacLM/yXSD0OeULPWJmnaDitD4bAW45MwYsEw0y7KCcg4iVOhjNC4V8HzewvJNwrdTWZ7blf5vxs0uFriuZbSVfpvS0g0Fe0PhZr/S6wfeuo4JxZL30yTALIqzftG4NZwHkZb11b/WdrDzEoBXLGcEQHOeIQMSgTNjahulxGaHkaDojrifobRTV0hHCz6ya6VKvrr94ile8GdX5n5v0T7oScP2L1Y+maaBJBVaY4Gzo3DqM7Prra4FrDixpAoaiP0dZoEwxW7KRKrUsGagPThRqrFCLBl50rY5myo7uKuNl9KPWIZWVR9f7WPlf9LtB968oDdi6VvpkkAWZXmd+S2KucZvJsvFqx619OVkik07CyAQGxdA/c015fk/wqeYfzk/J9/9wor/5doP3TzgCriPb9Y+maqJkE4leaDY3pPmNmO0xzz7OaMJ4obI3FTbnL7A8dZcgtGgCJ+82jfzcz/XWXl/4p+uEr5YSGZfkj1gLWLpW+mSQAbaG2gFjjbyjF0BMXQzkOY6ujmorsJGsaixOGw7WPqjvh1gMQwzKi6lrd+czDv2NTagfT+jfoCmJ+G0ZNvs/J/RT+cVH6IE0ejnrRDIRl+GFI9oLV9M1U5QMqHadEz5BhYu+TEs+QszJ1OMmtwUmOQOk6evs4s3IE+HnXew1BYNs0ytzDvL+Zu8rY6ye67iodN6XB1gJ3/K/rhiPJDmnF28oq1FJ/Uwmxu0b1s88OQ6gGt7ZtpiQDZlebnrvCMFcqSM3dCwuMojeNKcLzR3XTlYWxuMtSIq+Guel71fu+ovQJ4dxbWZ5bqC/q7t9n5v6IfZjw2m6bPcYCi9h7q2viQG1Z++J66/4x+qiKkpY9zT+C5esBF0TfTEgE20AEp2qgwe/SnP9c3NCVxgy1En4b5ebw8DWtJ/HDocV8jb4v2C73sTqrtV1vXwJYNq3jt+WlPhZxkzOxcx9uy30f+r+FgaxU/nKSLKt0uf6z8EDs8iuKKkggxLD+sAuYBuXm4pPbNtAhgbUuTfohNy2xyXbf0owFlZH8V567ojZPgjVEHcAuHi1/34vX9Q3Cwba3+EA15/i1fw7Rq7P36A7D96C44yImYMGfW0eWUJw/a6CR3zP5WeS8+8n+1LVmGH+bJD28rGw9QImM5CeECYujbDxlgHvDHXbw14Insm3EL4KPPwVMdndpjfXdL/LJPGcoDaEHLbHLqSaMdNrMKLt1hz1gZwSvh0BY4XPiac7Yum65BeOdyP1yB6mdUaBOkPT5zZlbi87007FzH8MNx8sN+8sMZekjmaci8pEQQV0RTlI95QIMCaFfftDACfAn0kviVsiQZWoSvxejEbJ4qh08cnfyEVsElyhCuMHDvPhOe0TBC+a3/ghfVy05bROPHH6VHAH3k/4p+WMfwwymPH6pocF7usFQQsYdklB/WhF+NgHnAu1cbmwm2o28ugC2TIAWNq2KYza00JyNP6K471DqJHgd+fRT1hSh+2Fl++2V4Vg03X1bfXrPhA8Q2HflP+AFYcj5JUHzk/4p+mGH44YTHD6er+OFM0a8aRzX80ACc3XIS0TctF8DAYTYtitaCKs3xmZofm9RP9h5si39N8JkrcLrp7+CrJ9+Gf1HfnrfB+BiNHv9vZ/PUVIifz/xf0Q9XMvxwxKcftlbwQ3fZY0A4u+VY0Td3+OubaRHAzCrGk5dmuJxKOwq5K0M5vfub41sTjPm+mr+B9sfOwDPq239T11s2GP5HP4eO3S/AU0ow/t2WNgV2pqVQv3WNr63WM6sY2757isbzNBzWoqIfDpJ8jJkRQuv7pmuTe/31zdSUwXAqzftHZsPsPIXc5UXPLVnpL37dWhdfBNjaCNsLX4PnMQJUIvivFG3FJjgvdMKLasj7qqcdOUgRuGTu+Cvss3Ib1jLq3TxF4/lhRmdX4rywH6K/3qLBIM6LroFiEfbS2MId832znE2aF3cEyKo07x2eNfKdG35OUFfupQzQTfrJAgDld2rjfKM4SzvwO/Dck78IvwrF8plYeGIHPN75G3BUteOz6tvdkDI2Nfoqrq2tW8rww1GPH44wNgDQ8cMC3Rn99zoUi7CHII5Fiub6ZiWb+NwYNQ0RILvSnIosUebWzUZ7mDtxdy3Gr2UmMWhdbOwnnuFs4Tcfgd/D12romY8rEsSaxe8chD1Y+qGiJeS1tAjgfavZa2LvXAVSzQ97SvxQE7YfTtFfGaHfwt9eQb1/qeV9U9cmPouh0xABsivNqfbQeR4ODqonziA9IfEahQVncDesDHcZEjdPdeKX4SjqUNxtObYHjp44AF9KUyS4uYm9Jrb6KpBSP+zy+CFjuOfbD2fIv3vJ19Hvw80VBuubjNUoG/xF7KkQwCwlQLXIT80mWXGQMHT5fWXwPtAqJab8jjU7Q2O0ceqz8DkbRPDJnXB46xo4APafCaz9gFHDe84ZGVmanNDzw+kSP+zXX/xvxA/R3/toeNwdmhAG65uM83Eoz7goc4Dzt5CqhDLv+M15i/XzPSP6T5mmjPlZYJzUwNnd3+yAvzx/k38w+mfudpbO/YLp9vzxq/Bsz6j+wegoxn/1MDykXm6DlPD5zayzcjPr6xnnXkyV+OFo9H5IIlxsxXW6eilKjLpvgnMWyHybDDFs4rMYOhUR4KZKy4+m54f9t+cv1p/ozukfwELrYmvBfBHq+ZNvw7MP/CN842If71xgnB3GTQsMR17nn34Dnv/MP8OznF/at9ER481pEUBmri27qZG/DC5OP6TlfnNg7OXuWuMK4XSIfbPUJqMlNhlg2GSZP5ukaUPU8sLXD3Obh07OW36EDFEeRpuKRajBwA+/l5ZgsTj8KSdhb/rQ6UtqWPYhJwrEzQaUfbZiQGijS9DmA9rQ7jGhnJVrgx8u6GuT1F96YG5pZwQ1hZ5lcEWbdDJt4qMYOhWTIPMqzd2NCPrpAyThcxmeb2TMNeQ4HSPkYmhWMtylYl1YMIb6xnhOGGexeDW6h3kPFxR0PENEMwpkrQKxwQ/R1yo+4KZKhJCfJ2StAvEsg5uzCcP//BRDp0IAnd0gXOH7EIpJ3QEo3WzUwbP8aFZ0qq7DjEZsHMHhJMNdQqxPZBXoRmCfQPiJrukMkRYtP2RsHmuLH/7slrPmuTKuEF6n/qUvhA20U4ueTQbK2IRxRrCfYuhUTIKsmFYC4CZxJ0F3d133METWmkMbiqFLocgjDNGZyE0aTInHPwQe5Q6Dd63XrgfMrGAeH2CDH+Ym9AVmdnjs9rXqQhitTXwUQ6ehEDrb1K8cdKl+JwDagNT9NzxXo7UxdrGxkXF2B7EcHAZzipUZNXdZmp1NlB/irjeHtvh5NNJIC+VmuIJN6hk2GStjk5yyyVpNmzTxbZJ0AXRWPHJ2LcYlXHj5/YM0zLFKAG1qk40RcukwmLPrtmZBdGL9EHe9+eYjMMpp+yzucrtcBZssY9hkn7LJvgA2yS6+ITC7+j4oFNJnQEgk1wZ5Q2DNgugk+2H3HeUwpvrmDvttknQBZFXfmyCMYmghOugMFRYaBdFJ9kNfpVdaffMTqo0Rbsnlpxg68REgzYZFRoC94gQL4NY2IhobIyTZDye4UbF238Tt4/yVz/iziRpub23m2STpAsjagtwU+1skCkww7NpGjbW3ifZDP1GxVt9cTqfduRsv5MMXwv1beDZJugDW0XKlSKGTvxpESxIJe8inURCdaD/0ExWz+ibOGPeREA5DqHsS0gl02jZJfASYXR79k5dO/pKJkGQyQQcesahSEJ10P+zWKogO2jdxB5pbdA2HEw3SCXTaNkl8DpBTfW8K20s9hMqc62YfdlStIDrpfth7odd4BFjeJrgn4QhFg+4JiiZtwiyGjk8A8WkwGfgu2dV10c6+ISEWQ0eeTF+M+BnybW6Ee2HhDSeS7odDKgI0PRFS2SYY/WFe0F1nnDdkE2YxdDwCOEhhcHABzNQti37oEWLhsa9kOq4gAL3D5QWfQ74NqyruuJN0P+zFgujZ/QHNoGeTSZjLDw4asEnW5hwgqv5HJH4Y+hYC3a0OywB8VbAHhJ5spmeBcR+97QfugYdFn8Iff3CX+FUoiE6LH5osiObbxM0PfgSBcoOrmbWA0SyFc4+XxDc3Ze4J09rAdzrc6fjpN+78oPHISUbuxXsSfcHAe9l74gDsOdgKezjrVAX/nd3PGlgsiFaREk6E9KbQD3u5ywSN983/WcAmzzNssoJnk3AFsEAh7gipu+EcQ4Dq+x9AcSm3y5e5N8ClTx1dTqgdKHDHYy6V0x8Oco8yWysJGkM+7hrYBQqiU+GHfh8KkfTNArD2ecYleB2dejYJbwg8TcLXG4r4Ib4mDDxHERaCPDVbsk6NkxUzwbSzyAQIHHIDed5scEv5PGBa/DDnZ3Y8kr45whsWtzTp28S8AJbuyBzebnKmqu/R0BPcBLBNxdC0iapEgMyIhzsRgkNO1bGbYX5BdFr8cNxgQbRZm9xQNmEsqeMUQ5sXQPeMXVwCMxOqA5usvs/TKV3abGq054zg0+85TnsLBNYw2E/tW5mC6DT5oamCaLM2wV3JvUvqqsTLdBCTlk3MCeA0jdz7IxuMZWmzylhgnhgWGvjExic3aJ1sLHjwVftWpiA6TX5oqiA6HJu4S+q6K0eC2Tp9mwQXQHfI20fD3UJkn32m3kftVdfQvINXfMPYKThUXr/hHKN5VfSM39n91L6VOSkuTX7YbWhjhHBtMgZzpXRlhHBDY1QR4ATMVXMPRu7AvqrvVbRkxPHoA459PfDfv+kI4DXRM38dnlv7VmYfvjT5IeYBBwwURIdvkyGP7pSMOOtr9W3iXwDdXB9GfpOROy5OimcN1szl6KBqbUIqhmZx5gqc7uiCs7E8ftJB7uZIoB2i0+iHQQuio7MJ6k7/nQEYpxiaL4AzNNR1Q9B4yGxdE33lvZeSItTI6RqEdx47A99VL8+LjvkfBvvJeXl2iE6jHwbdITpam2DKzV1FQuUyJcXQhgVwjBR3JlbHzdJmkCwotJ8AQ5lKOgci8lIYjPw2/QP8oXrZCVL/Fyja8ZPz8hREp9EPu/1sFxZ735yBuVlidZeDbXo24a8EwX28pmJ33ExzPf8pQyUGeVONwGp3NQTNhjkExVlemuhwDvQ5/orz+iJFfiJ+wZjNeXFWhHhOinvHMj80EgEGOikuzr6JutRX1CjHJher982aQqG64NbUzIskH1RXmyFjY0d+zefv+mlHjv7mWyX/vkldO9S1MWD7TdrGBT/Sq572v894Svppj1dcsZp+L/MeC4lz0LaYem+l/ua+P85qiglP22zyQ+7ntVD/49qk9HOyrm8upHN+BBAM5huCDgFqDP89E/cznRO0wUY1htpr4+dl4j3a9r5qIm5HwfbP2rQACoIgJIZAAigIgpBGlogJBEEQARQEQRABFARBEAEUBEEQARQEQRABFARBEAEUBEEQARQEQUgs/y/AAMVg1D54gFHbAAAAAElFTkSuQmCC'>
				<p>
				$c[kori] <b>$result[username]</b><br><br>
				$c[pass] <b>$result[password]</b>
				</p>
				<p><b><a href='".URL.LANG."/login'>$c[activb]</a></b></p>
				</center>";

				mail($to, $subject, $txt, $headers);

				header('Location: '.ROOT.LANG.'/info/send-activ');
			} else {

				return "<p class='red'>$c[nouser]</p>";
			}
		}
	}

	public static function Register($username, $email, $password, $cpassword) {

		if (LANG == 'eng') {
			
			require 'lang/eng/engine.php';
		} else {
			
			require 'lang/srb/engine.php';
		}

		if ($password != $cpassword) {

			return "<p class='red'>$c[nopa]</p>";
		} else {

			if (strlen($username) < 3 OR strlen($username) > 16 OR strlen($password) < 3 OR strlen($password) > 16) {

				return "<p class='red'>$c[nostr]</p>";
			} else {

				if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			
					return "<p class='red'>$c[nevem]</p>";
				} else {

					$link = new DB();
					$query = "SELECT * FROM users WHERE username = ? OR email = ?";
					$result = $link->GetRow($query, [$username, $email]);

					if ($result) {

						return "<p class='red'>$c[exisu]</p>";
					} else {

						$session = md5($email);

						$query = "INSERT INTO users (username, email, password, session, usertype, activ) VALUES (?, ?, ?, ?, ?, ?)";
						$result = $link->InsertRow($query, [$username, $email, $password, $session, 1, 0]);

						$to = $email;

						$subject = 'Fabrikana';

						$headers = "From: office@fabrikana.com\r\n";
						$headers .= "MIME-Version: 1.0\r\n";
						$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
						
						$txt =
						"<style>
							a {
								color: darkorange;
								text-decoration: none;
							}
							a:hover {
								color: #ccc;
							}
						</style>
						<center>

						 <img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUAAAAB2CAYAAAC5xEquAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAABZ+SURBVHja7J0NbBzHdccf9cGjKB1JfZmRaDtUpVgSpUqBhcoQZDsVYEBOgACy0DRA4dSqi4hNgaaVmhZNXRQF0tYF2sqGCyR1iigy4BZ10yoqCqQh6sCtbMG10gS2HMqSLVl0LEqmKVIkj1/Hr+u8vbfk8nS8m7c7uzu7fD9gwaNELufevfnvmzdvZmoKhQIIgiAsRpaICQRBEAEUBEEQARQEQRABFARBEAEUBEEQARQEQRABFARBSD7LdH6opqZGLCUIQmJZqN55mc/7xamIUrktCEJ0EWAJD6qrLcY2X1TXa/LRCYIQtQC2nToC7U/sg8fjanBNO7SrL+ckEhQEISgyCSIIggigIAiCCKAgCIIIoCAIggigIAiCCKAgCIIIoCAIggigIAiCCKAgCIIIoCAIggigIAiCCKAgCIIIoCAIggigIAiCCKAgCIIIoCAIggigIAiCCKAgCELYLIvzjz/6HDzV0Qm3mL+GZ4LIdviCICRbAImX1DXE+HkRP0EQUiOAImqCIMSC5AAFQRABFARBEAEUBEEQARQEQRABFARBSCXLUvzeagzco5CgvxtWe+JsSyHC+9WEZJM4/KEmYvsWktpH0iiA69TVpq5tBu7Vp65OdV3S/PkH6W8H5Zq6euk1/u1xn/cx0R60wVXP993quuXDAf20BYvez6trwuD9XjNwr4XuE7cf1qprL+O94Pt4S125gDap9DnZ0jcXjQC2vfF1+PO9rfBQ0Bv1DMEHn/gD+H1NI7edOgLtT+yDx4P+3Ys34Sfv9sAH+PqPTsOrl3ugR718hxxtQtcOJtqDNnj9ffiJ+/1/XIBLJ885bdN1et9tOfMmnH7sW/AN9fJNE/d74XV48cgp6Ke2u2w+8QX40rFH4KjufZ55Gb59/Htws+TBYIMftn3/K3Ds0KfhsM59f3QJOh55Bv5MvfzfIPat8DnZ0jcXlQA23JV1njSBqVsOK+mpGq2Cb4A9eOFrdObBMbj1ymU4q5zsn0w89Tg0N8AnVRs+6X6vXsN3fn3W6SNvTwis33X33PvT4fmzzsOoO+l+uHOjE4m1LOa+mcZJkOzqelhv4kaNK5wPK2soZxGoHSiEH/01/O3BHc7TfXfcRratPQFoISHQjjxURP6hRlrCej/Eh9vWZrgH9WSx9s00CmBGPR3qTd1MdXA0dIMNbwwd9qUvwzHltAfUt5ssa09LAn2lDgUA34fuL/zshhPtdqfFD9sfhu0RfnbW2SRtAogO3ZRZZs7I99/rPLGytrxBfPL98HedfNUOW9pz+itOrqgtgf7SQgKgzYXrTv6zNy1+SMP/9Yu1b6ZNADOt68wZGFEfmjURoEvrWth+6gh80ZahJ+YrT3wBfgXMzO5FSVj5v8T4YYR5QCttYosA1mhcWjkGeiqYjHDwQ6u1rece+jQ8alPU9Wt74aAtUSknAgwr/5cUP4wwD2ilTWyYBf6i5s9h7gXLFyptoNpATwVjbGxyPrQG23ouDj1VFPi5I6ecOq6LcbcHO9KT++H+k+fgrMYQ0ZZ0SVj5v0T5IaYBjn/PiQKvhmhvK20SqwD+8KvwF7o/e74LXn3gafgT9fJshR+rpaeCMVZlnPtlbOzBv9Q6m8C+aEN7Pr8LtikBbEmIAIaV/0ucH3rygGEKoJU2Sd0kSLbOqQ8yxtqV9uUAXTavj3QGryr3NUeWUDcBK/+Xn4JRFSW9rikSifLDiPKAVtokbQKY3dBoNsxuqrdrFtgLzqipYeenbBEd2wS5WgTIyf9d7dWa/EikH1IaYC2EW+9qpU1SNwtcX2s2zEaRwel7CClJjCsqatqhfdufwjEc5vt4ehuNDNz24HIvTPrbZCuT0Qg3/0dLE3vT6ofqQYq2WLfY+mbqIkBTleZe9m8JPQo8f7kHXnzgafgWLnvj/OKmdbMV8Ubbo4Z7zzxxCr7N/cXD94fekYxEf9z8H66B5kSASfNDzN+GHL1baZM0CSCG71laImN6iBDFRAgK37X/+2Bu4wEdQpwdvNTRCRe6+pyhnzbrV9k7aeRtJjf/d/IcvKcZASbSD0PO31prkzQJYEaFw6wQWzfairAYeuj6bd4Masiz1EMf53gR6ZqViRDAMPN/ifTDkPO31tokTQKYpXBY28C3R/XEJsJi6CE1FGYJDuVVQhPAGwMlNsJdAKdLrkkoboqlrsblC9gKS4eH6cLd5/Ak6EG63O9znp8ZhsrlxlP0d0vbMqPVacLM/yXSD0OeULPWJmnaDitD4bAW45MwYsEw0y7KCcg4iVOhjNC4V8HzewvJNwrdTWZ7blf5vxs0uFriuZbSVfpvS0g0Fe0PhZr/S6wfeuo4JxZL30yTALIqzftG4NZwHkZb11b/WdrDzEoBXLGcEQHOeIQMSgTNjahulxGaHkaDojrifobRTV0hHCz6ya6VKvrr94ile8GdX5n5v0T7oScP2L1Y+maaBJBVaY4Gzo3DqM7Prra4FrDixpAoaiP0dZoEwxW7KRKrUsGagPThRqrFCLBl50rY5myo7uKuNl9KPWIZWVR9f7WPlf9LtB968oDdi6VvpkkAWZXmd+S2KucZvJsvFqx619OVkik07CyAQGxdA/c015fk/wqeYfzk/J9/9wor/5doP3TzgCriPb9Y+maqJkE4leaDY3pPmNmO0xzz7OaMJ4obI3FTbnL7A8dZcgtGgCJ+82jfzcz/XWXl/4p+uEr5YSGZfkj1gLWLpW+mSQAbaG2gFjjbyjF0BMXQzkOY6ujmorsJGsaixOGw7WPqjvh1gMQwzKi6lrd+czDv2NTagfT+jfoCmJ+G0ZNvs/J/RT+cVH6IE0ejnrRDIRl+GFI9oLV9M1U5QMqHadEz5BhYu+TEs+QszJ1OMmtwUmOQOk6evs4s3IE+HnXew1BYNs0ytzDvL+Zu8rY6ye67iodN6XB1gJ3/K/rhiPJDmnF28oq1FJ/Uwmxu0b1s88OQ6gGt7ZtpiQDZlebnrvCMFcqSM3dCwuMojeNKcLzR3XTlYWxuMtSIq+Guel71fu+ovQJ4dxbWZ5bqC/q7t9n5v6IfZjw2m6bPcYCi9h7q2viQG1Z++J66/4x+qiKkpY9zT+C5esBF0TfTEgE20AEp2qgwe/SnP9c3NCVxgy1En4b5ebw8DWtJ/HDocV8jb4v2C73sTqrtV1vXwJYNq3jt+WlPhZxkzOxcx9uy30f+r+FgaxU/nKSLKt0uf6z8EDs8iuKKkggxLD+sAuYBuXm4pPbNtAhgbUuTfohNy2xyXbf0owFlZH8V567ojZPgjVEHcAuHi1/34vX9Q3Cwba3+EA15/i1fw7Rq7P36A7D96C44yImYMGfW0eWUJw/a6CR3zP5WeS8+8n+1LVmGH+bJD28rGw9QImM5CeECYujbDxlgHvDHXbw14Insm3EL4KPPwVMdndpjfXdL/LJPGcoDaEHLbHLqSaMdNrMKLt1hz1gZwSvh0BY4XPiac7Yum65BeOdyP1yB6mdUaBOkPT5zZlbi87007FzH8MNx8sN+8sMZekjmaci8pEQQV0RTlI95QIMCaFfftDACfAn0kviVsiQZWoSvxejEbJ4qh08cnfyEVsElyhCuMHDvPhOe0TBC+a3/ghfVy05bROPHH6VHAH3k/4p+WMfwwymPH6pocF7usFQQsYdklB/WhF+NgHnAu1cbmwm2o28ugC2TIAWNq2KYza00JyNP6K471DqJHgd+fRT1hSh+2Fl++2V4Vg03X1bfXrPhA8Q2HflP+AFYcj5JUHzk/4p+mGH44YTHD6er+OFM0a8aRzX80ACc3XIS0TctF8DAYTYtitaCKs3xmZofm9RP9h5si39N8JkrcLrp7+CrJ9+Gf1HfnrfB+BiNHv9vZ/PUVIifz/xf0Q9XMvxwxKcftlbwQ3fZY0A4u+VY0Td3+OubaRHAzCrGk5dmuJxKOwq5K0M5vfub41sTjPm+mr+B9sfOwDPq239T11s2GP5HP4eO3S/AU0ow/t2WNgV2pqVQv3WNr63WM6sY2757isbzNBzWoqIfDpJ8jJkRQuv7pmuTe/31zdSUwXAqzftHZsPsPIXc5UXPLVnpL37dWhdfBNjaCNsLX4PnMQJUIvivFG3FJjgvdMKLasj7qqcdOUgRuGTu+Cvss3Ib1jLq3TxF4/lhRmdX4rywH6K/3qLBIM6LroFiEfbS2MId832znE2aF3cEyKo07x2eNfKdG35OUFfupQzQTfrJAgDld2rjfKM4SzvwO/Dck78IvwrF8plYeGIHPN75G3BUteOz6tvdkDI2Nfoqrq2tW8rww1GPH44wNgDQ8cMC3Rn99zoUi7CHII5Fiub6ZiWb+NwYNQ0RILvSnIosUebWzUZ7mDtxdy3Gr2UmMWhdbOwnnuFs4Tcfgd/D12romY8rEsSaxe8chD1Y+qGiJeS1tAjgfavZa2LvXAVSzQ97SvxQE7YfTtFfGaHfwt9eQb1/qeV9U9cmPouh0xABsivNqfbQeR4ODqonziA9IfEahQVncDesDHcZEjdPdeKX4SjqUNxtObYHjp44AF9KUyS4uYm9Jrb6KpBSP+zy+CFjuOfbD2fIv3vJ19Hvw80VBuubjNUoG/xF7KkQwCwlQLXIT80mWXGQMHT5fWXwPtAqJab8jjU7Q2O0ceqz8DkbRPDJnXB46xo4APafCaz9gFHDe84ZGVmanNDzw+kSP+zXX/xvxA/R3/toeNwdmhAG65uM83Eoz7goc4Dzt5CqhDLv+M15i/XzPSP6T5mmjPlZYJzUwNnd3+yAvzx/k38w+mfudpbO/YLp9vzxq/Bsz6j+wegoxn/1MDykXm6DlPD5zayzcjPr6xnnXkyV+OFo9H5IIlxsxXW6eilKjLpvgnMWyHybDDFs4rMYOhUR4KZKy4+m54f9t+cv1p/ozukfwELrYmvBfBHq+ZNvw7MP/CN842If71xgnB3GTQsMR17nn34Dnv/MP8OznF/at9ER481pEUBmri27qZG/DC5OP6TlfnNg7OXuWuMK4XSIfbPUJqMlNhlg2GSZP5ukaUPU8sLXD3Obh07OW36EDFEeRpuKRajBwA+/l5ZgsTj8KSdhb/rQ6UtqWPYhJwrEzQaUfbZiQGijS9DmA9rQ7jGhnJVrgx8u6GuT1F96YG5pZwQ1hZ5lcEWbdDJt4qMYOhWTIPMqzd2NCPrpAyThcxmeb2TMNeQ4HSPkYmhWMtylYl1YMIb6xnhOGGexeDW6h3kPFxR0PENEMwpkrQKxwQ/R1yo+4KZKhJCfJ2StAvEsg5uzCcP//BRDp0IAnd0gXOH7EIpJ3QEo3WzUwbP8aFZ0qq7DjEZsHMHhJMNdQqxPZBXoRmCfQPiJrukMkRYtP2RsHmuLH/7slrPmuTKuEF6n/qUvhA20U4ueTQbK2IRxRrCfYuhUTIKsmFYC4CZxJ0F3d133METWmkMbiqFLocgjDNGZyE0aTInHPwQe5Q6Dd63XrgfMrGAeH2CDH+Ym9AVmdnjs9rXqQhitTXwUQ6ehEDrb1K8cdKl+JwDagNT9NzxXo7UxdrGxkXF2B7EcHAZzipUZNXdZmp1NlB/irjeHtvh5NNJIC+VmuIJN6hk2GStjk5yyyVpNmzTxbZJ0AXRWPHJ2LcYlXHj5/YM0zLFKAG1qk40RcukwmLPrtmZBdGL9EHe9+eYjMMpp+yzucrtcBZssY9hkn7LJvgA2yS6+ITC7+j4oFNJnQEgk1wZ5Q2DNgugk+2H3HeUwpvrmDvttknQBZFXfmyCMYmghOugMFRYaBdFJ9kNfpVdaffMTqo0Rbsnlpxg68REgzYZFRoC94gQL4NY2IhobIyTZDye4UbF238Tt4/yVz/iziRpub23m2STpAsjagtwU+1skCkww7NpGjbW3ifZDP1GxVt9cTqfduRsv5MMXwv1beDZJugDW0XKlSKGTvxpESxIJe8inURCdaD/0ExWz+ibOGPeREA5DqHsS0gl02jZJfASYXR79k5dO/pKJkGQyQQcesahSEJ10P+zWKogO2jdxB5pbdA2HEw3SCXTaNkl8DpBTfW8K20s9hMqc62YfdlStIDrpfth7odd4BFjeJrgn4QhFg+4JiiZtwiyGjk8A8WkwGfgu2dV10c6+ISEWQ0eeTF+M+BnybW6Ee2HhDSeS7odDKgI0PRFS2SYY/WFe0F1nnDdkE2YxdDwCOEhhcHABzNQti37oEWLhsa9kOq4gAL3D5QWfQ74NqyruuJN0P+zFgujZ/QHNoGeTSZjLDw4asEnW5hwgqv5HJH4Y+hYC3a0OywB8VbAHhJ5spmeBcR+97QfugYdFn8Iff3CX+FUoiE6LH5osiObbxM0PfgSBcoOrmbWA0SyFc4+XxDc3Ze4J09rAdzrc6fjpN+78oPHISUbuxXsSfcHAe9l74gDsOdgKezjrVAX/nd3PGlgsiFaREk6E9KbQD3u5ywSN983/WcAmzzNssoJnk3AFsEAh7gipu+EcQ4Dq+x9AcSm3y5e5N8ClTx1dTqgdKHDHYy6V0x8Oco8yWysJGkM+7hrYBQqiU+GHfh8KkfTNArD2ecYleB2dejYJbwg8TcLXG4r4Ib4mDDxHERaCPDVbsk6NkxUzwbSzyAQIHHIDed5scEv5PGBa/DDnZ3Y8kr45whsWtzTp28S8AJbuyBzebnKmqu/R0BPcBLBNxdC0iapEgMyIhzsRgkNO1bGbYX5BdFr8cNxgQbRZm9xQNmEsqeMUQ5sXQPeMXVwCMxOqA5usvs/TKV3abGq054zg0+85TnsLBNYw2E/tW5mC6DT5oamCaLM2wV3JvUvqqsTLdBCTlk3MCeA0jdz7IxuMZWmzylhgnhgWGvjExic3aJ1sLHjwVftWpiA6TX5oqiA6HJu4S+q6K0eC2Tp9mwQXQHfI20fD3UJkn32m3kftVdfQvINXfMPYKThUXr/hHKN5VfSM39n91L6VOSkuTX7YbWhjhHBtMgZzpXRlhHBDY1QR4ATMVXMPRu7AvqrvVbRkxPHoA459PfDfv+kI4DXRM38dnlv7VmYfvjT5IeYBBwwURIdvkyGP7pSMOOtr9W3iXwDdXB9GfpOROy5OimcN1szl6KBqbUIqhmZx5gqc7uiCs7E8ftJB7uZIoB2i0+iHQQuio7MJ6k7/nQEYpxiaL4AzNNR1Q9B4yGxdE33lvZeSItTI6RqEdx47A99VL8+LjvkfBvvJeXl2iE6jHwbdITpam2DKzV1FQuUyJcXQhgVwjBR3JlbHzdJmkCwotJ8AQ5lKOgci8lIYjPw2/QP8oXrZCVL/Fyja8ZPz8hREp9EPu/1sFxZ735yBuVlidZeDbXo24a8EwX28pmJ33ExzPf8pQyUGeVONwGp3NQTNhjkExVlemuhwDvQ5/orz+iJFfiJ+wZjNeXFWhHhOinvHMj80EgEGOikuzr6JutRX1CjHJher982aQqG64NbUzIskH1RXmyFjY0d+zefv+mlHjv7mWyX/vkldO9S1MWD7TdrGBT/Sq572v894Svppj1dcsZp+L/MeC4lz0LaYem+l/ua+P85qiglP22zyQ+7ntVD/49qk9HOyrm8upHN+BBAM5huCDgFqDP89E/cznRO0wUY1htpr4+dl4j3a9r5qIm5HwfbP2rQACoIgJIZAAigIgpBGlogJBEEQARQEQRABFARBEAEUBEEQARQEQRABFARBEAEUBEEQARQEQUgs/y/AAMVg1D54gFHbAAAAAElFTkSuQmCC'>
						<p><b><a href='".URL.LANG."/activation/".$session."'>$c[activb]</a></b></p>
						</center>";

						mail($to, $subject, $txt, $headers);

						header('Location: '.ROOT.LANG.'/info/send-activ');
					}
				}
			}
		}
	}
}

?>