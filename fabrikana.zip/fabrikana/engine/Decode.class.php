<?php

if (!defined('PROTECT')){die('Protected Content!');}

class Decode {
	
	public function Output() {

		$content = ob_get_contents();
		ob_end_clean();

		$content = self::Converter($content);
		
		if (COMPRESS == 1) {
			
			$content = self::Compress($content);
		}

		if (LANG === 'lat') {
			
			$content = self::Transliteration($content);	
		}
		
		return $content;
	}

	static private function Converter($input) {
		
		$conversion_table = self::ConversionTable();

		$output = strtr ($input, $conversion_table);
		
		return $output;
	}

	static private function ConversionTable() {

		if (LANG == 'eng') {
			
			require_once 'lang/eng/meta.php';
		} else {
			
			require_once 'lang/srb/meta.php';
		}

		if (C1 == 'blog') {$title = TITLE.' | '.$c['blog'];} 
		else if (C1 == 'kategorije') {$title = TITLE.' | '.$c['categories'];}
		else if (C1 == 'arhiva') {$title = TITLE.' | '.$c['archive'];}
		else if (C1 == 'manifest') {$title = TITLE.' | '.$c['manifest'];}
		else if (C1 == 'kontakt') {$title = TITLE.' | '.$c['contact'];}
		else if (C1 == 'prijavi-se') {$title = TITLE.' | '.$c['signin'];}
		else if (C1 == 'odjavi-se') {$title = TITLE.' | '.$c['signout'];}
		else if (C1 == 'pisi') {$title = TITLE.' | '.$c['write'];}
		else if (C1 == 'edituj') {$title = TITLE.' | '.$c['edit'];}
		else if (C1 == 'izbrisi') {$title = TITLE.' | '.$c['delete'];}
		else if (C1 == 'slike') {$title = TITLE.' | '.$c['images'];}
		else if (C1 == 'dodaj-kategoriju') {$title = TITLE.' | '.$c['addc'];}
		else if (C1 == 'edituj-kategoriju') {$title = TITLE.' | '.$c['editc'];}
		else if (C1 == 'izbrisi-kategoriju') {$title = TITLE.' | '.$c['deletec'];}
		else if (C1 == 'komentari') {$title = TITLE.' | '.$c['comments'];}
		else {

			$title = TITLE;
		}

		$body = Content::Body();

		return $conversion_table = array (
			
			"{%html_lang%}"			=> $c['html_lang'],
			"{%charset%}"			=> $c['charset'],
			"{%description%}"		=> $c['description'],
			"{%keywords%}"			=> $c['keywords'],
			"{%author%}"			=> $c['author'],
			"{%favicon%}"			=> FAVICON,
			"{%style%}"				=> STYLE,
			"{%title%}"				=> $title,
			"{%body%}"				=> $body
		);
	}
	
	static private function Compress($input) {

		$content = str_replace(array("\r\n", "\r"), "\n", $input);
		$lines = explode("\n", $content);
		$new_lines = array();

		foreach ($lines as $i => $line) {
		    
		    if(!empty($line)) {
		        $new_lines[] = trim($line);
		    }
		}

		$content = implode($new_lines);

		return $content;
	}

	static private function Transliteration($input) {
		
		$transliteration_sr_ci_la = self::TransliterationTable();

		$output = strtr ($input, $transliteration_sr_ci_la);

		return $output;
	}

	static private function TransliterationTable() {
		
		$transliteration_sr_ci_la = array (
			"А" => "A", "Б" => "B", "В" => "V", "Г" => "G", "Д" => "D", "Ђ" => "Đ", "Е" => "E", "Ж" => "Ž", "З" => "Z", "И" => "I", 
			"Ј" => "J", "К" => "K", "Л" => "L", "Љ" => "LJ", "М" => "M", "Н" => "N", "Њ" => "NJ", "О" => "O", "П" => "P", "Р" => "R", 
			"С" => "S", "Т" => "T", "Ћ" => "Ć", "У" => "U", "Ф" => "F", "Х" => "H", "Ц" => "C", "Ч" => "Č", "Џ" => "DŽ", "Ш" => "Š", 

			"а" => "a", "б" => "b", "в" => "v", "г" => "g", "д" => "d", "ђ" => "đ", "е" => "e", "ж" => "ž", "з" => "z", "и" => "i", 
			"ј" => "j", "к" => "k", "л" => "l", "љ" => "lj", "м" => "m", "н" => "n", "њ" => "nj", "о" => "o", "п" => "p", "р" => "r", 
			"с" => "s", "т" => "t", "ћ" => "ć", "у" => "u", "ф" => "f", "х" => "h", "ц" => "c", "ч" => "č", "џ" => "dž", "ш" => "š", 

			"Ља" => "Lja", "Ље" => "Lje", "Љи" => "Lji", "Љо" => "Ljo", "Љу" => "Lju", 
			"Ња" => "Nja", "Ње" => "Nje", "Њи" => "Nji", "Њо" => "Njo", "Њу" => "Nju", 
			"Џа" => "Dža", "Џе" => "Dže", "Џи" => "Dži", "Џо" => "Džo", "Џу" => "Džu"
		);

		return $transliteration_sr_ci_la;
	}
}

?>