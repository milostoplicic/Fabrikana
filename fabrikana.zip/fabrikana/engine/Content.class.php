<?php

if (!defined('PROTECT')){die('Protected Content!');}

class Content {
	
	public function __construct() {

		require_once 'temp/site.php';
	}

	static public function Body() {

		if ($_SESSION[SITE]['usertype'] == 0) {

			return self::Cont();
		} else if ($_SESSION[SITE]['usertype'] != 0) {

			return self::Nav().self::Cont().self::Footer();
		}
	}

	static private function Cont() {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/site.php';
		} else {

			require 'lang/srb/site.php';
		}

		if ($_SESSION[SITE]['usertype'] == 0) { // guest

			if (C1 == HOME OR C1 == '') {

				require_once 'engine/inc/login.php';
			} else if (C1 == 'register') {

				require_once 'engine/inc/register.php';
			} else if (C1 == 'forgot') {

				require_once 'engine/inc/forgot.php';
			} else if (C1 == 'activation') {

				require_once 'engine/inc/activation.php';
			} else {

				require_once 'engine/inc/info.php';
			}
		} else if ($_SESSION[SITE]['usertype'] == 1) { // user
			
			if (C1 == 'blog' OR C1 == '') {
				
				require_once 'engine/inc/blog.php';
			} else if (C1 == 'kategorije') {
				
				require_once 'engine/inc/categories.php';
			} else if (C1 == 'arhiva') {
				
				require_once 'engine/inc/archive.php';
			} else if (C1 == 'manifest') {
				
				require_once 'engine/inc/manifest.php';
			} else if (C1 == 'kontakt') {
				
				require_once 'engine/inc/contact.php';
			} else if (C1 == 'odjavi-se') {
				
				require_once 'engine/inc/logout.php';
			} else if (C1 == 'clanak') {
				
				require_once 'engine/inc/article.php';
			} else if (C1 == 'arhiva-za') {
				
				require_once 'engine/inc/archive-for.php';
			} else if (C1 == 'kategorija') {
				
				require_once 'engine/inc/category.php';
			} else if (C1 == 'clanci-od-korisnika') {

				require_once 'engine/inc/articles-from-user.php';
			} else {
				
				require_once 'engine/inc/info.php';
			}
		} else if ($_SESSION[SITE]['usertype'] == 2) { // moderator
			
			if (C1 == 'blog' OR C1 == '') {
				
				require_once 'engine/inc/blog.php';
			} else if (C1 == 'kategorije') {
				
				require_once 'engine/inc/categories.php';
			} else if (C1 == 'arhiva') {
				
				require_once 'engine/inc/archive.php';
			} else if (C1 == 'manifest') {
				
				require_once 'engine/inc/manifest.php';
			} else if (C1 == 'kontakt') {
				
				require_once 'engine/inc/contact.php';
			} else if (C1 == 'odjavi-se') {
				
				require_once 'engine/inc/logout.php';
			} else if (C1 == 'pisi') {
				
				require_once 'engine/inc/write.php';
			} else if (C1 == 'edituj') {
				
				require_once 'engine/inc/edit.php';
			} else if (C1 == 'izbrisi') {
				
				require_once 'engine/inc/delete.php';
			} else if (C1 == 'slike') {
				
				require_once 'engine/inc/images.php';
			} else if (C1 == 'dodaj-kategoriju') {
				
				require_once 'engine/inc/add-category.php';
			} else if (C1 == 'edituj-kategoriju') {
				
				require_once 'engine/inc/edit-category.php';
			} else if (C1 == 'izbrisi-kategoriju') {
				
				require_once 'engine/inc/delete-category.php';
			} else if (C1 == 'clanak') {
				
				require_once 'engine/inc/article.php';
			} else if (C1 == 'kategorija') {
				
				require_once 'engine/inc/category.php';
			} else if (C1 == 'arhiva-za') {
				
				require_once 'engine/inc/archive-for.php';
			} else if (C1 == 'clanci-od-korisnika') {

				require_once 'engine/inc/articles-from-user.php';
			} else {
				
				require_once 'engine/inc/info.php';
			}
		} else if ($_SESSION[SITE]['usertype'] == 3) { // administrator
			
			if (C1 == 'blog' OR C1 == '') {
				
				require_once 'engine/inc/blog.php';
			} else if (C1 == 'kategorije') {
				
				require_once 'engine/inc/categories.php';
			} else if (C1 == 'arhiva') {
				
				require_once 'engine/inc/archive.php';
			} else if (C1 == 'manifest') {
				
				require_once 'engine/inc/manifest.php';
			} else if (C1 == 'kontakt') {
				
				require_once 'engine/inc/contact.php';
			} else if (C1 == 'odjavi-se') {
				
				require_once 'engine/inc/logout.php';
			} else if (C1 == 'pisi') {
				
				require_once 'engine/inc/write.php';
			} else if (C1 == 'edituj') {
				
				require_once 'engine/inc/edit.php';
			} else if (C1 == 'izbrisi') {
				
				require_once 'engine/inc/delete.php';
			} else if (C1 == 'slike') {
				
				require_once 'engine/inc/images.php';
			} else if (C1 == 'dodaj-kategoriju') {
				
				require_once 'engine/inc/add-category.php';
			} else if (C1 == 'edituj-kategoriju') {
				
				require_once 'engine/inc/edit-category.php';
			} else if (C1 == 'izbrisi-kategoriju') {
				
				require_once 'engine/inc/delete-category.php';
			} else if (C1 == 'clanak') {
				
				require_once 'engine/inc/article.php';
			} else if (C1 == 'kategorija') {
				
				require_once 'engine/inc/category.php';
			} else if (C1 == 'arhiva-za') {
				
				require_once 'engine/inc/archive-for.php';
			} else if (C1 == 'clanci-od-korisnika') {

				require_once 'engine/inc/articles-from-user.php';
			} else if (C1 == 'komentari') {

				require_once 'engine/inc/comments.php';
			} else {
				
				require_once 'engine/inc/info.php';
			}
		}

		return $cont;
	}
	
	static private function Nav() {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/nav.php';
		} else {

			require 'lang/srb/nav.php';
		}

		if (C1 == '') {$c1 = '';} else {$c1 = C1.'/';}
		if (C2 == '') {$c2 = '';} else {$c2 = C2.'/';}
		if (C3 == '') {$c3 = '';} else {$c3 = C3.'/';}
		if (C4 == '') {$c4 = '';} else {$c4 = C4.'/';}
		
		$b = '';
		$k = '';
		$a = '';
		$m = '';
		$ko = '';
		
		if (C1 == '' OR C1 == 'blog') {
			$b = "class='active'";
		} else if (C1 == 'kategorije') {
			$k = "class='active'";
		} else if (C1 == 'arhiva') {
			$a = "class='active'";
		} else if (C1 == 'manifest') {
			$m = "class='active'";
		} else if (C1 == 'kontakt') {
			$ko = "class='active'";
		}
		
		require_once 'temp/nav.php';
		
		return $nav;
	}
	
	static private function Footer() {
		
		if (LANG == 'eng') {
			
			require 'lang/eng/footer.php';
		} else {

			require 'lang/srb/footer.php';
		}

		require_once 'temp/footer.php';
		
		return $footer;
	}
}

?>