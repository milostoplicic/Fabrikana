<?php

if (!defined('PROTECT')){die('Protected Content!');}

$e = "<p>&nbsp</p>";

if (isset($_POST['submit'])) {

	if ($_POST['email'] == '') {

		$e = "<p class='red'>$c[une]</p>";
	} else {

		$e = Engine::Forgot($_POST['email']);
	}
}

$cont =
"
<div id='login'>
	<a href='".ROOT."'><img src='".ROOT."look/img/fabrikana_logo.png'></a>
	<div id='linkse'><a href='".ROOT."eng/".C1."'>Eng</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='".ROOT."cyr/".C1."'>Cyr</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='".ROOT."lat/".C1."'>Lat</a></div>
	$e
	<form action='' method='post'>
		<p>$c[tekfor]</p>
		<input type='text' name='email' placeholder='$c[email]' maxlength='32' class='fil1'><br>
		<input type='submit' name='submit' value='$c[pot]' class='but1'><br><br>
		<p class='small'>$c[imna] <a href='".ROOT.LANG."/login'>$c[signin]</a></p>
	</form>
</div>
"

?>