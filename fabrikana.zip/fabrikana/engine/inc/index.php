<?php

die('Protected Content!');

?>