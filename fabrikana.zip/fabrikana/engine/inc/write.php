<?php

if (!defined('PROTECT')){die('Protected Content!');}

$error = '';

$authorid = Engine::AuthorId($_SESSION[SITE]['username']);

if (isset($_POST['submit'])) {
	
	if (empty($_POST['header']) OR empty($_POST['tekst'])) {
		
		$error = "<p class='red'>$c[popobpo]</p>";
	} else {
		
		$comments = isset($_POST['comments']) ? 1 : 0;
		$engleski = isset($_POST['engleski']) ? 1 : 0;
		$error = Engine::Write($engleski, $_POST['header'], $_POST['header_en'], $_POST['catid'], $_POST['tekst'], $_POST['tekst_en'], $authorid, $_POST['minview'], $comments);
	}
}

$selectbox = Engine::SelectBox('');

$cont =
"
<div id='cont'>
<h1>$c[pisi]</h1>
$error
<form action='' method='post'>
$c[naslov]&nbsp;&nbsp;<input type='text' name='header' class='fil3' maxlength='128'><br><br>
$c[kategori]&nbsp;&nbsp;<select class='selbox1' name='catid'>$selectbox</select><br><br>
$c[predpregled] <input type='text' name='minview' class='fil4' value='400'><br><br>
$c[comen2] <input type='checkbox' name='comments' checked><br><br>
$c[tekst]<br>
<textarea id='edit' name='tekst'></textarea><br><br>
$c[eng] <input type='checkbox' id='check' name='engleski' onclick='Engleski()'><br><br>
<div id='engleski' style='display:none'>
$c[naslov_en]&nbsp;&nbsp;<input type='text' name='header_en' class='fil3' maxlength='128'><br><br>
<textarea id='edit_en' name='tekst_en'></textarea>
</div><br><br>
<input type='submit' name='submit' class='but1' value='$c[pot]'>
</form>
<script src='".ROOT."engine/tinymce/tinymce.min.js'></script>
<script>tinymce.init({
		relative_urls : false,
		remove_script_host : true,
		document_base_url : '".ROOT."',
		content_css : '".ROOT.'look/css/style.css'."',
		  selector: 'textarea',
		  height: 400,
		  theme: 'modern',
		  plugins: [
			'advlist autolink lists link image charmap print preview hr anchor pagebreak',
			'searchreplace wordcount visualblocks visualchars code fullscreen',
			'insertdatetime media nonbreaking save table contextmenu directionality',
			'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc'
		  ],
		  toolbar1: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
		  toolbar2: 'print preview media | forecolor backcolor emoticons | codesample',
		  image_advtab: true
		 });

			function Engleski() {
			var checkBox = document.getElementById('check');
			var text = document.getElementById('engleski');
			if (checkBox.checked == true){
			text.style.display = 'block';
			} else {
			text.style.display = 'none';
			}
			}
		 </script>
</div>
";

?>