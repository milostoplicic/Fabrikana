<?php

if (!defined('PROTECT')){die('Protected Content!');}

$e = '';
$s = '';

if (isset($_POST['submit'])) {

	if ($_FILES['photo']['name']) {

		if ($_FILES['photo']['size'] > (1024000)) {

			$e .= "<p class='red'>$c[slikapre]</p>";
		} else {
		
			$imageFileType = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);

			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {

				$e .= "<p class='red'>$c[nijeslika]</p>";
			} else {
				
				$rand = rand(0, 100);
				
				$date = date("m-Y");
				
				if (!file_exists('content/img/'.$date)) {
					
					mkdir('content/img/'.$date, 0777, true);
				}
				
				$target = 'content/img/'.$date.'/'. $rand . basename($_FILES['photo']['name']);
				move_uploaded_file($_FILES['photo']['tmp_name'], $target);

				$e .= "<p>$c[slikauh] ".ROOT.$target."</p>";	
			}
		}
	}
}

$s .= 
"
<p class='green'>$c[sveslike] <a href='".ROOT."content/img/'>".ROOT."content/img/</a></p>
$e
<form action='' method='post' enctype='multipart/form-data'>
	$c[vasaslika] &nbsp; <input type='file' name='photo' size='25'>
	<input type='submit' name='submit' class='but1' value='$c[posalji]'>
</form>
";

$cont =
"
<div id='cont'>
<h1>$c[slike33]</h1>
$s
</div>
";

?>