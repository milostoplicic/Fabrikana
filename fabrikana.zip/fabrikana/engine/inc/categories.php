<?php

if (!defined('PROTECT')){die('Protected Content!');}

$s = '';

$link = new DB();
$query = "SELECT * FROM categories";
$result = $link->GetRows($query);

foreach ($result as $r) {
	
	$query1 = "SELECT COUNT(*) FROM articles WHERE catid = ?";
	$result1 = $link->GetRow($query1, [$r['catid']]);
	
	$total = $result1['COUNT(*)'];
	
	if ($r['image'] == '') {
		
		$img = '';
	} else {
		
		$img = "<img class='catimg' src='".$r['image']."'>";
	}

	if (LANG == 'eng') {
		
		$s .= 
		"
		<div class='block2'>
		<h2><a href='".ROOT.LANG."/kategorija/".$r['catseo']."'>$r[catname_en] ($total)</a></h2>
		$img
		<p>$r[catdesc_en]</p>
		</div>
		";
	} else {

		$s .= 
		"
		<div class='block2'>
		<h2><a href='".ROOT.LANG."/kategorija/".$r['catseo']."'>$r[catname] ($total)</a></h2>
		$img
		<p>$r[catdesc]</p>
		</div>
		";
	}
}

$cont =
"
<div id='cont'>
<h1>$c[cate2]</h1>
$s
<div class='clear'></div>
</div>
";

?>