<?php

if (!defined('PROTECT')){die('Protected Content!');}

$link = new DB();

$query0 = "SELECT * FROM users WHERE session = ?";
$result0 = $link->GetRow($query0, [C2]);

$_SESSION[SITE] = array(

	'username'		=> $result0['username'],
	'session'		=> $result0['session'],
	'usertype'		=> $result0['usertype']
);

$query = "UPDATE users SET activ = 1 WHERE session = ?";
$result = $link->UpdateRow($query, [C2]);


header('Location: '.ROOT.LANG.'/blog');

?>