<?php

if (!defined('PROTECT')){die('Protected Content!');}

$s1 = rand(0, 10);
$s2 = rand(0, 10);
$s3 = md5($s1 + $s2);

$s = '';
$e = '';
$comme = '';

if (C2 != '') {
	
	$link = new DB();
	
	if (!isset($_SESSION[SITE][C2])) {
		
		$query1 = "UPDATE articles SET pregledi = pregledi + 1 WHERE seo = ?";
		$result1 = $link->UpdateRow($query1, [C2]);
	
		$_SESSION[SITE][C2] = 1;
	}
	
	$query = "SELECT * FROM articles WHERE seo = ?";
	$result = $link->GetRow($query, [C2]);
	
	if ($result) {
		
		if ($result['comments'] == 0) {
			
			$co = ' | '.$c['comof'];
			$coform = '';
		} else {

			$queryc = "SELECT COUNT(*) FROM comments WHERE artid = ? AND pub = 1";
			$resultc = $link->GetRow($queryc, [$result['artid']]);

			$tot = $resultc['COUNT(*)'];

			$co = ' | '.$c['come']. " <b>".$tot."</b>";

			if (isset($_POST['submit'])) {

				$name = $_POST['name'];
				$message = $_POST['message'];

				if (md5($_POST['s3']) == $_POST['s3check']) {

					if (empty($name) AND empty($message)) {

						$e = "<p class='red'>$c[popobpo]</p>";
					} else {
						
						$cdate = date("Y-m-d H:i:s");
						
						$queryu = "INSERT INTO comments(name, comment, artid, cdate, pub) VALUES(?, ?, ?, ?, ?)";
						$resultu = $link->InsertRow($queryu, [$name, $message, $result['artid'], $cdate, 0]);

						$e = "<p class='green'>$c[compoa]</p>";
					}
				} else {

					$e = "<p class='red'>$c[pogre]</p>";
				}
			}

			$queryco = "SELECT * FROM comments WHERE artid = ? AND pub = 1 ORDER BY comid DESC";
			$resultco = $link->GetRows($queryco, [$result['artid']]);
			
			if ($resultco) {
				
				foreach ($resultco as $rc) {

					$datum = explode(' ', $rc['cdate']);
					$datum1 = explode('-', $datum[0]);
					$datum2 = $datum1[2].'.'.$datum1[1].'.'.$datum1[0];

					$time = $datum[1];

					$comme .=
					"
					<p>$c[ime] <b>$rc[name]</b> | $c[date] <b>".$datum2."</b>".' | '.$c['vreme'].' <b>'.$time."</b></p>
					<p>$rc[comment]</p>
					<div class='line'></div>
					";	
				}
			} else {

				$comme = "<p class='red'>$c[nocom]</p>";
			}

			$coform = 
			"
				<br>
				<div class='line'></div>
				<h2>$c[uncom]</h2>
				<form action='' method='post'>
					$c[ime2]<br>
					<input type='text' name='name' maxlength='20' placeholder='$c[ime3]' class='fil3'><br><br>
					$c[por1]<br>
					<textarea class='fil2' name='message' maxlength='200' placeholder='$c[por2]'></textarea><br><br>
					$c[iz] $s1 $c[plus] $s2 = <input type='text' name='s3' class='fil4'><br><br>
					<input type='hidden' value='$s3' name='s3check'>
					<input type='submit' name='submit' class='but1' value='$c[posalji]'>
				</form>
				<br>
				<div class='line'></div>
				<h2>$c[comen2]</h2>
				$comme
			";
		}

		$date = explode('-', $result['date']);
		$date = $date[2].'.'.$date[1].'.'.$date[0];
		
		$cat = Engine::CatName($result['catid'], $result['engleski']);

		$catseo = Engine::CatSeo($result['catid']);
		
		$author = Engine::Author($result['authorid']);
		
		if (LANG == 'eng' AND $result['engleski'] == 1) {
			
			$s .=
			"
			<h2>$result[header_en]</h2>
			<p class='date'>$c[date] <b>$date</b> | $c[cate] <a href='".ROOT.LANG."/kategorija/".$catseo."'><b>$cat</b></a> | $c[author] <a href='".ROOT.LANG."/clanci-od-korisnika/".$author."'><b>$author</b></a> | $c[pregledi] <b>$result[pregledi]</b>$co</p>
			$result[tekst_en]
			$coform
			";
		} else {
			
			$s .=
			"
			<h2>$result[header]</h2>
			<p class='date'>$c[date] <b>$date</b> | $c[cate] <a href='".ROOT.LANG."/kategorija/".$catseo."'><b>$cat</b></a> | $c[author] <a href='".ROOT.LANG."/clanci-od-korisnika/".$author."'><b>$author</b></a> | $c[pregledi] <b>$result[pregledi]</b>$co</p>
			$result[tekst]
			$coform
			";
		}
	} else {
		
		$s = "<p>$c[nocontent]</p>";
	}
} else {
	
	$s = "<p>$c[nocontent]</p>";
}

$cont =
"
<div id='cont'>
$e
$s
</div>
";

?>