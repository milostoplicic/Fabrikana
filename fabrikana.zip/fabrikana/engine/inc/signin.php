<?php

if (!defined('PROTECT')){die('Protected Content!');}

$e = '';

if (isset($_POST['submit'])) {
	
	$username = $_POST['username'];
	$password = $_POST['password'];
	$remember = isset($_POST['remember']) ? 1 : 0;
	
	if (empty($username) OR empty($password)) {
		
		$e = "<p class='red'>$c[popobpo]</p>";
	} else {
		
		$e = Engine::Signin($username, $password, $remember);
	}
}

$cont =
"
<div id='cont'>
<h1>$c[signin]</h1>
$e
<form action='' method='post'>
$c[korime]<br> 
<input type='text' name='username' placeholder='$c[korime2]' maxlength='20' class='fil1'><br><br>
$c[lozinka]<br>
<input type='password' name='password' placeholder='$c[lozinka2]' maxlength='20' class='fil1'><br><br>
$c[zapamtime] <input type='checkbox' name='remember' checked>
<input type='submit' name='submit' class='but1' value='$c[pot]'>
</form>
</div>
";

?>