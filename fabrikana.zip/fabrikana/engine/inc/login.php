<?php

if (!defined('PROTECT')){die('Protected Content!');}

$e = "<p>&nbsp</p>";

if (isset($_POST['submit'])) {
	
	$username = $_POST['username'];
	$password = $_POST['password'];
	$remember = isset($_POST['remember']) ? 1 : 0;
	
	if (empty($username) OR empty($password)) {
		
		$e = "<p class='red'>$c[popobpo]</p>";
	} else {
		
		$e = Engine::Login($username, $password, $remember);
	}
}

$cont =
"
<div id='login'>
	<a href='".ROOT."'><img src='".ROOT."look/img/fabrikana_logo.png'></a>
	<div id='linkse'><a href='".ROOT."eng/".C1."'>Eng</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='".ROOT."cyr/".C1."'>Cyr</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='".ROOT."lat/".C1."'>Lat</a></div>
	$e
	<form action='' method='post'>
		<input type='text' name='username' maxlength='16' placeholder='$c[korime2]' class='fil1'><br>
		<input type='password' name='password' maxlength='16' placeholder='$c[lozinka2]' class='fil1'><br><br>
		$c[zapamtime] <input type='checkbox' name='remember' checked><br>
		<input type='submit' name='submit' value='$c[pot]' class='but1'><br><br>
		<p class='small'>$c[nematn] <a href='".ROOT.LANG."/register'>$c[naprav]</a><br><br>
		$c[zaboravp] <a href='".ROOT.LANG."/forgot'>$c[kliko]</a>
		</p>
	</form>
</div>
";
?>