<?php

if (!defined('PROTECT')){die('Protected Content!');}

if ($_SESSION[SITE]['usertype'] == 0) {
	
	$sig = "$c[copy] &nbsp;&nbsp; | &nbsp;&nbsp; <a href='".ROOT.LANG."/prijavi-se'>$c[signin]</a>";
} else if ($_SESSION[SITE]['usertype'] == 1) {

		$sig = "$c[copy] | ".$_SESSION[SITE]['username']." | <a href='".ROOT.LANG."/odjavi-se'>$c[signout]</a>";
} else if ($_SESSION[SITE]['usertype'] > 1) {
	
	$sig = 
	"
	$c[copy]<br><br>
	".$_SESSION[SITE]['username']."
	 | <a href='".ROOT.LANG."/odjavi-se'>$c[signout]</a>
	 | <a href='".ROOT.LANG."/pisi'>$c[write]</a>
	 | <a href='".ROOT.LANG."/edituj'>$c[edit]</a>
	 | <a href='".ROOT.LANG."/izbrisi'>$c[delete]</a>
	 | <a href='".ROOT.LANG."/slike'>$c[images]</a>
	 | <a href='".ROOT.LANG."/dodaj-kategoriju'>$c[add_category]</a>
	 | <a href='".ROOT.LANG."/edituj-kategoriju'>$c[edit_category]</a>
	 | <a href='".ROOT.LANG."/izbrisi-kategoriju'>$c[delete_category]</a>
	 | <a href='".ROOT.LANG."/komentari'>$c[comments]</a>
	";
} else {

	$sig = '';
}

$footer =
"
<div id='footer'>
$sig
</div>
";

?>