<?php

if (!defined('PROTECT')){die('Protected Content!');}

$c = array(
	
	'copy'				=> "Ауторско Право <b>&copy;</b> 2019, 2020 СкупРа",
	'signin'			=> 'Пријави се',
	'signout'			=> 'Одјави се',
	'write'				=> 'Пиши',
	'edit'				=> 'Едитуј',
	'delete'			=> 'Избриши',
	'images'			=> 'Слике',
	'add_category'		=> 'Додај категорију',
	'edit_category'		=> 'Едитуј категорију',
	'delete_category'	=> 'Избриши категорију',
	'comments'			=> 'Коментари'
);

?>