<?php

if (!defined('PROTECT')){die('Protected Content!');}

// cookie name
define('SITE', 'fabrikana');

// This is the folder on the hosting, if it is root, leave only a slash. The folder is "skupra" to me and that's why it says so
define('ROOT', '/fabrikana/');

// Address site
define('URL', 'http://localhost/fabrikana/');

// default language = "eng" or "lat" or "cyr"
define('DFLANG', 'cyr');

// compression 1 or 0
define('COMPRESS', 0);

// homepage
define('HOME', 'login');

// Title on browser
define('TITLE', 'Fabrikana');

// favicon
define('FAVICON', ROOT.'look/img/fabrikana_favicon.png');

// default css style
define('STYLE', ROOT.'look/css/style.css');

// database
define('HOST', 'localhost');
define('USERNAME', 'root');
define('PASSWORD', '');
define('DBNAME', 'fabrikana');

// email for contact
define('EMAIL', 'office@fabrikana.com');

function Path() {

	$path = isset($_GET['path']) ? $_GET['path'] : '';
	$path = explode ('/', $path);

	return $path;
}

$path = Path();

if ($path[0] == 'eng') {

	define('LANG', 'eng');
} else if ($path[0] == 'cyr') {

	define('LANG', 'cyr');
} else if ($path[0] == 'lat') {
	
	define('LANG', 'lat');
} else {
	
	define('LANG', DFLANG);
}

define('C1', isset($path[1]) ? $path[1] : '');
define('C2', isset($path[2]) ? $path[2] : '');
define('C3', isset($path[3]) ? $path[3] : '');
define('C4', isset($path[4]) ? $path[4] : '');

?>