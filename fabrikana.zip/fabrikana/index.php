<?php

// protection against loading individual files
define('PROTECT', 'fabrikana');

// errors
ini_set('display_errors', E_ALL);
error_reporting(1);

// session start
// buffer start
session_start();
ob_start();

// base config file
require_once 'config.php';

// database
require_once 'engine/DB.class.php';

// initialization
require_once 'engine/Init.class.php';

// content
require_once 'engine/Content.class.php';

// decode
require_once 'engine/Decode.class.php';

// engine
require_once 'engine/Engine.class.php';

$init = new Init;
$init->Start();

$content = new Content();

$decode = new Decode;
echo $decode->Output();

?>